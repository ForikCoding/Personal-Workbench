/**
 * The Host services the skill card consumes, declared narrowly.
 *
 * The plugin reads only these members, so it states them here rather than
 * depending on upstream declaration files — the same choice the layout route
 * makes for Connection's trust fence.
 * @module dsh-workbench/skill-card-host
 */
import type { WorkbenchSandboxMode } from './skill-card-contract.ts';
/**
 * Raised when one session cannot take a sandbox mode.
 *
 * Typed rather than a plain `Error` so the runner can turn exactly this failure into a
 * refusal naming the mode it could not apply, while a fault raised anywhere else still
 * travels as itself instead of being reported as a permission problem.
 */
export declare class WorkbenchSandboxModeError extends Error {
    readonly sessionId: string;
    readonly mode: WorkbenchSandboxMode;
    /**
     * @param sessionId - the session the mode was meant for.
     * @param mode - the mode that could not be recorded.
     * @param detail - why, when the cause has a message of its own.
     */
    constructor(sessionId: string, mode: WorkbenchSandboxMode, detail?: string);
}
/** One live agent. The agent object doubles as the skill registry's scope key. */
export interface WorkbenchAgent {
    /** Shared agent/session identity. */
    readonly id: string;
    /**
     * The agent's session.
     *
     * Its header carries the effective working directory, which is the fallback
     * for channels that predate the working-directory service.
     */
    readonly session?: {
        readonly header?: {
            readonly cwd?: string;
        };
    };
    /**
     * The route the agent runs on, when one is named.
     *
     * A fresh session this feature creates has no route of its own unless the card names
     * one, so the run inherits the naming session's route here. That is what makes every
     * run — the session and the subagent it starts — able to assemble the deployment
     * persona, whose `{{model}}` template variable is read off the agent's own options.
     */
    readonly options?: {
        readonly provider?: string;
        readonly model?: string;
    };
    /**
     * The agent's own scoped context, when the channel exposes it.
     *
     * Read for one question only: which Agent preset this agent composed, so a card's run
     * session can be created under the same one. The narrower the better — nothing else may
     * reach through this field.
     */
    readonly ctx?: unknown;
}
/**
 * Composed Agent presets, as far as a run needs them.
 *
 * A preset is what brings the coding tools — `read`, `write`, `edit`, `glob`, `grep`,
 * `pwsh` — into an agent's scope: they are contributed by the preset's own composition, not
 * registered globally. An agent created without one therefore runs with only the globally
 * mounted tools (MCP servers, this plugin's own), and a skill that has to read a file or
 * write a report has no way to do either.
 */
export interface WorkbenchAgentPresetSeam {
    /**
     * Resolve a preset identity.
     * @param id - requested preset, or the deployment default when omitted.
     * @returns the resolved identity.
     */
    resolve(id?: string): Promise<{
        readonly id: string;
    }>;
    /**
     * Bind an unpublished Agent to a preset revision.
     * @param ctx - the agent's scoped creation context.
     * @param id - resolved preset identity.
     * @returns resolution once the preset is bound.
     */
    mount(ctx: unknown, id: string): Promise<unknown>;
    /**
     * Read the preset a live agent composed.
     * @param ctx - the agent's scoped context.
     * @returns its preset id, or undefined in a preset-free composition.
     */
    composedPreset?(ctx: unknown): string | undefined;
}
/**
 * Composition callback for one unpublished Agent.
 *
 * The harness awaits it before the agent is published, which is the only window in which a
 * preset can be bound: binding later would compose a world the agent has already assembled
 * a prompt from.
 */
export type WorkbenchAgentSetup = (agentCtx: unknown, agent: WorkbenchAgent) => Promise<void> | void;
/** Base a loaded skill resolves the relative paths it mentions against. */
export type WorkbenchSkillResourceBase = {
    readonly kind: 'directory';
    readonly path: string;
} | {
    readonly kind: 'url';
    readonly url: string;
} | {
    readonly kind: 'opaque';
    readonly description: string;
};
/** Resolved model and user invocation controls. */
export interface WorkbenchSkillInvocation {
    readonly modelInvocable: boolean;
    readonly userInvocable: boolean;
}
/** One skill as the catalog lists it. */
export interface WorkbenchSkillSummary {
    /** Kebab-case identifier. */
    readonly name: string;
    /** Short routing description. */
    readonly description: string;
    /** Optional extra routing guidance. */
    readonly whenToUse?: string;
    /** Invocation controls. */
    readonly invocation: WorkbenchSkillInvocation;
}
/** One loaded skill, including the instruction body. */
export interface WorkbenchSkillDefinition extends WorkbenchSkillSummary {
    /** Markdown instruction body. */
    readonly content: string;
    /** Provider that owns the body. */
    readonly provider: string;
    /** Provider-specific base for relative resources. */
    readonly resourceBase?: WorkbenchSkillResourceBase;
}
/**
 * View options every skill read takes.
 *
 * `scope` selects the reading agent's layers. The upstream Web composition
 * registers no filesystem provider in the global layer and disables the host row,
 * so a scope-less read returns nothing there; the Desktop layer mounts its own
 * host-plane provider instead, which is what makes the installed catalog readable
 * before any session exists.
 */
export interface WorkbenchSkillLookup {
    /** Workspace directory selecting project roots; absent when none is resolvable. */
    readonly cwd?: string;
    /** Reading agent; absent reads the global layer alone. */
    readonly scope?: WorkbenchAgent;
    /** Cancellation. */
    readonly signal: AbortSignal;
}
/** One block of a child's final output, narrowed to the text this feature keeps. */
export interface WorkbenchContentBlock {
    readonly type: string;
    readonly text?: string;
}
/**
 * Terminal outcome of one child run.
 *
 * `stopReason` is a plain string because the upstream union is merge-extensible;
 * a non-`completed` reason means the output may be partial.
 */
export interface WorkbenchSubagentResult {
    readonly output: readonly WorkbenchContentBlock[];
    /** Validated structured value, absent when no valid capture was committed. */
    readonly structured?: unknown;
    /** Provider-authored failure detail. */
    readonly diagnostic?: string;
    readonly stopReason: string;
}
/** One started child execution. */
export interface WorkbenchActivation {
    readonly childId: string;
    readonly result: Promise<WorkbenchSubagentResult>;
    /**
     * Stop the run and release its resources.
     * @returns resolution after teardown.
     */
    dispose(): Promise<void>;
}
/**
 * One model a provider route advertises, narrowed to the field this feature checks.
 *
 * Only membership matters here: the display name a picker would show comes from the
 * Client's own catalog, never from the Host's validation query.
 */
export interface WorkbenchModelInfo {
    readonly id: string;
}
/**
 * Child Agent route override for one run.
 *
 * Structurally the upstream `AgentOptions` fields this feature sets, declared here for
 * the same reason the rest of this module is: the plugin reads only these members. The
 * upstream type also carries `reasoningEffort` and `maxTokens`, which v1 deliberately
 * does not send — an effort the card never chose would be a value it never had.
 */
export interface WorkbenchAgentOptions {
    /** Provider route owning the model. */
    readonly provider: string;
    /** Model id the provider advertises. */
    readonly model: string;
}
/**
 * One requested child execution.
 *
 * `agentOptions` is present but optional, and a run that omits it inherits the session's
 * model — which is what a card with no model selected does. `toolFilter` is used to remove
 * only the goal tools, whose promise of a later round a card run cannot keep; every other
 * tool the session has stays available to the run.
 */
export interface WorkbenchActivationSpec {
    readonly provider: string;
    readonly label: string;
    readonly signal: AbortSignal;
    /** `caller` returns the result without notifying the parent model loop. */
    readonly delivery: 'parent' | 'caller';
    readonly request: {
        readonly parent: WorkbenchAgent;
        readonly prompt: readonly WorkbenchContentBlock[];
        /** Initial child directory; omitted inherits the parent's at start. */
        readonly cwd?: string;
        /**
         * Output contract the child must satisfy; omitted asks for no structured value.
         *
         * A bare run omits it: nothing is asked for, so nothing can fail to arrive, and the
         * child's own stop reason is the verdict.
         */
        readonly outputSchema?: unknown;
        /**
         * Route the child runs on; omitted inherits the parent's route at start.
         *
         * The seam merges this over the parent's own route, so naming a provider and a model
         * replaces both and a partial override cannot happen. The seam also rejects it
         * outright for a backend without {@link WorkbenchSubagentHost.getProvider}'s
         * `agentOptions` capability, which is why the runner checks that first.
         */
        readonly agentOptions?: WorkbenchAgentOptions;
        /**
         * Global tools to hide from the child.
         *
         * Intersected with what the session already allows, and it never widens: the run starts
         * with the session's tools minus these names. See the runner's deny list for the three
         * that are removed and why a run must not see them.
         */
        readonly toolFilter?: {
            readonly allow?: readonly string[];
            readonly deny?: readonly string[];
        };
    };
}
/** Subagent surface, narrowed to provider discovery and one activation. */
export interface WorkbenchSubagentHost {
    /**
     * Registered backend names.
     * @returns every currently registered provider name.
     */
    list(): readonly string[];
    /**
     * Look one backend up.
     * @param name - provider name.
     * @returns the provider when registered, otherwise undefined.
     */
    getProvider(name: string): {
        readonly capabilities: {
            readonly outputSchema: boolean;
            /** Whether the backend accepts a per-run {@link WorkbenchAgentOptions} override. */
            readonly agentOptions: boolean;
        };
    } | undefined;
    /**
     * Start one child execution through the activation seam.
     *
     * Optional because the seam a run uses is a property of the installed harness:
     * `0.2.1-alpha.2` provides this method, while `0.2.0-rc.2` — the stable channel —
     * provides the one-shot `start` below instead. A harness offering neither is still a
     * valid deployment — the workbench loads and its cards stay readable and editable —
     * so the surface says so instead of pretending the method exists. The runner prefers
     * this seam and wraps {@link WorkbenchSubagentHost.start} when only it exists.
     * @param spec - provider, label, cancellation, delivery, and request.
     * @returns the started activation.
     */
    startActivation?(spec: WorkbenchActivationSpec): Promise<WorkbenchActivation>;
    /**
     * Start one child execution through the one-shot seam the older channel offers.
     *
     * Optional because the seam a run uses is a property of the installed harness:
     * `0.2.1-alpha.2` replaced this method with `startActivation`, and `0.2.0-rc.2` —
     * the stable channel this plugin ships into — has exactly this method. Measured
     * on a real host composition: the request takes the same `prompt`, `parent`,
     * `signal`, `outputSchema` and `agentOptions` the activation request takes (no
     * `cwd`, no `delivery` — the child inherits the parent's header at start and the
     * result resolves to the caller), the sandbox mode reaches the child through the
     * parent's recorded override, and the returned handle carries `id` where the
     * activation carries `childId`.
     * @param provider - registered backend name.
     * @param spec - label, cancellation, and request.
     * @returns the started execution's handle.
     */
    start?(provider: string, spec: WorkbenchStartSpec): Promise<WorkbenchStartHandle>;
}
/**
 * One requested child execution on the older channel's one-shot seam.
 *
 * Declared structurally against `0.2.0-rc.2`'s `SubagentStartRequest`, narrowed to
 * the members a card run sets. `cwd` and `delivery` are deliberately absent: the
 * older request has neither, and a card run never needed them — the child's sandbox
 * root comes from the parent's session header, and the result resolves to the caller.
 */
export interface WorkbenchStartSpec {
    /** Optional short display label persisted with the child. */
    readonly label?: string;
    /** Content delivered as the child's user message. */
    readonly prompt: readonly WorkbenchContentBlock[];
    /** The spawning agent; derives workspace, lineage, and delegation depth. */
    readonly parent: WorkbenchAgent;
    /** Cancellation; canonical both before and after startup. */
    readonly signal: AbortSignal;
    /** Output contract the child must satisfy; omitted asks for no structured value. */
    readonly outputSchema?: unknown;
    /** Route the child runs on; omitted inherits the parent's route. */
    readonly agentOptions?: WorkbenchAgentOptions;
}
/** One started child execution on the older channel's one-shot seam. */
export interface WorkbenchStartHandle {
    /** Session identity of the child. */
    readonly id: string;
    /** Terminal outcome; resolves when the child settles. */
    readonly result: Promise<WorkbenchSubagentResult>;
    /**
     * Stop the run and release its resources.
     * @returns resolution after teardown.
     */
    dispose(): Promise<void>;
}
/**
 * The activation seam itself, once the harness is known to provide it.
 *
 * Bound to the subagent service before it is carried around: the real method reads its
 * own receiver, so a bare function reference would not be callable outside it.
 */
export type WorkbenchActivationSeam = (spec: WorkbenchActivationSpec) => Promise<WorkbenchActivation>;
/**
 * Working-directory service.
 *
 * It arrived after the stable channel's pinned harness, so a deployment may not
 * provide it at all. The runner therefore reads it optionally and falls back to
 * the session header, which is how the older channel resolves the same value.
 */
export interface WorkbenchWorkingDirectory {
    /**
     * Resolve the agent's effective working directory.
     * @param agent - the agent.
     * @param signal - cancellation.
     * @returns the absolute directory.
     */
    ensure(agent: WorkbenchAgent, signal: AbortSignal): Promise<string>;
}
/** The Host services one skill card run needs. */
export interface WorkbenchSkillCardHost {
    readonly agents: {
        /**
         * Look up the live agent driving one session.
         * @param sessionId - session identity.
         * @returns the agent, or undefined when no live agent has that id.
         */
        get(sessionId: string): WorkbenchAgent | undefined;
        /**
         * Every live agent, in registration order.
         *
         * The installed catalog is only visible through an agent scope: the shipped
         * web composition disables the host's own skill provider so each preset owns
         * local discovery, which leaves the global layer empty. A card is configured
         * before it is ever run, so the catalog falls back to any live agent rather
         * than refusing until the user opens the session it will run in.
         * @returns the live agents.
         */
        list(): readonly WorkbenchAgent[];
        /**
         * Create an agent whose session header carries its own `cwd`.
         *
         * This is the only way a card can own a file-sandbox root: the sandbox policy
         * derives `workspaceRoot` from `session.header.cwd`, and the subagent seam copies a
         * child's header from its **parent**. A card agent created here therefore fences
         * every run started with it as `parent`, without teaching the seam anything new.
         *
         * `sessionId` is required: creating without one fails at publish time with
         * `agent id "undefined" does not match session id`.
         * @param options - session identity, the directory to root it at, and its parent.
         * @returns the created agent and the handle that tears it down.
         */
        create(options: {
            readonly sessionId: string;
            /**
             * Session metadata, including the preset the session is composed under.
             *
             * A session created without a preset runs with only the globally mounted tools: its
             * child then has no `read`, `write`, or `pwsh` either, because a child joins its
             * parent's preset rather than the deployment's. A skill that must write a file
             * cannot, and says so in prose instead.
             */
            readonly meta: {
                readonly cwd: string;
                readonly agentPreset?: string;
            };
            readonly parentAgent?: WorkbenchAgent;
            /**
             * Composition window, where the preset named in `meta` is actually bound.
             *
             * Both fields are needed: `meta.agentPreset` records the identity on the session, and
             * this binds the revision the run executes under.
             */
            readonly setup?: WorkbenchAgentSetup;
            /**
             * The route the session runs on, when one is named.
             *
             * A run session is created blank; the deployment personae assemble `{{model}}` off
             * the agent's own options, so a session without a route cannot assemble them, and
             * nor can the subagent it parents. The runner names the card's route or the naming
             * session's, so assembling is never the first failure a run meets.
             */
            readonly agentOptions?: {
                readonly provider?: string;
                readonly model?: string;
            };
        }): Promise<WorkbenchAgentHandle>;
        /**
         * Load one persisted session and run an agent on it again.
         *
         * The way back into a session whose agent is gone: a run releases its agent when it
         * settles, and `create` would refuse the id that already exists durably, so a
         * refinement of that run's result re-attaches here instead. The resumed agent carries
         * the session's own header — the directory the card ran in at the time, and the
         * permission mode its log recorded — which is what keeps a refinement in the
         * conversation it revises.
         *
         * `agentOptions` re-names the route for a session that predates the workbench naming
         * one: an older run session was persisted without it, and the resumed agent inherits
         * that blankness unless the route is stated here.
         * @param options - the persisted session to load.
         * @returns the re-attached agent and the handle that tears it down.
         */
        resume(options: {
            readonly resumeSessionId: string;
            /** Route to install on the resumed agent; see {@link create} for the warrant. */
            readonly agentOptions?: {
                readonly provider?: string;
                readonly model?: string;
            };
            /** Preset binding for the resumed agent; see {@link create} for why it is needed. */
            readonly setup?: WorkbenchAgentSetup;
        }): Promise<WorkbenchAgentHandle>;
    };
    /**
     * Agent presets, when the deployment composes them.
     *
     * Optional because a channel may pin a harness without the registry; a run then composes
     * exactly as it did before presets existed rather than refusing to start.
     */
    readonly agentPresets?: WorkbenchAgentPresetSeam;
    /**
     * The sandbox mode a card's own agent runs under.
     *
     * A setter rather than a field on the created agent: a mode is recorded as a session
     * event, and the policy service that reads it has no writer of its own. The card's agent
     * is the session that decides every run started from it, because a child inherits its
     * parent's explicit override — so this one call is what makes the card's mode govern its
     * runs.
     */
    readonly sandbox: {
        /**
         * Record one sandbox mode on one live agent's session.
         * @param sessionId - session whose mode changes; the card's own agent.
         * @param mode - the mode every later confined call in that session runs under.
         * @throws {WorkbenchSandboxModeError} when no live agent has that session, or the
         * session refuses the event.
         */
        setMode(sessionId: string, mode: WorkbenchSandboxMode): void;
    };
    readonly skills: {
        /**
         * List the catalog one agent's scope chain selects.
         * @param options - cwd, scope, and cancellation.
         * @returns the merged catalog.
         */
        list(options: WorkbenchSkillLookup): Promise<readonly WorkbenchSkillSummary[]>;
        /**
         * Load one skill's body.
         * @param name - skill name.
         * @param options - cwd, scope, and cancellation.
         * @returns the loaded skill, or undefined when it is not available.
         */
        get(name: string, options: WorkbenchSkillLookup): Promise<WorkbenchSkillDefinition | undefined>;
    };
    /**
     * Session lifecycle the workbench needs but no other service exposes.
     *
     * A card's run hangs from an agent the plugin creates, and creating a published agent
     * also creates a session — which the sidebar would otherwise list for every card the
     * user ever ran. Archiving is `archivedSessionIds` bookkeeping, not deletion: the
     * session stays readable and its log stays refinable. Restoring it is the same
     * bookkeeping in reverse, and it is what a refinement needs: an archived session, or a
     * subagent descendant of one, is refused its first model step.
     */
    readonly workspaceRegistry: {
        /**
         * Every session currently hidden from the default list.
         *
         * Read rather than assumed: a refinement restores a session only when it is archived,
         * and puts it back in the state it found, so a session the user has open is neither
         * hidden nor restored on their behalf.
         * @returns the archived session ids.
         */
        readonly archivedSessionIds: readonly string[];
        /**
         * Hide a session from the default list.
         * @param sessionId - the session to archive.
         * @returns resolution once the archive is recorded.
         */
        archiveSession(sessionId: string): Promise<void>;
        /**
         * Return a session to the default list.
         *
         * Called before a run continues an archived session — a session is archived as soon as
         * its run settles, so every refinement restores one first and archives it again when it
         * settles in turn.
         * @param sessionId - the session to restore.
         * @returns resolution once the archive set no longer holds it.
         */
        unarchiveSession(sessionId: string): Promise<void>;
    };
    readonly subagents: WorkbenchSubagentHost;
    /**
     * LLM registry, narrowed to the one query a start consults.
     *
     * A card that names a model has to be checked against what the deployment can actually
     * route *before* a child is created. Refusing here is what keeps a stale card from
     * silently running on the session's model instead of the one it displays.
     */
    readonly llm: {
        /**
         * Discover models advertised by one provider route.
         *
         * Rejects for a provider this registry does not have, which is how a start tells a
         * missing provider apart from a missing model.
         * @param provider - provider route to inspect.
         * @returns the advertised models.
         */
        listModels(provider: string): Promise<readonly WorkbenchModelInfo[]>;
    };
}
/**
 * A created agent and the handle that tears it down.
 *
 * The handle is separate because disposal is not the agent's concern: the plugin owns the
 * lifetime — create on the card's first run, dispose when the card's workspace changes or
 * the card is removed.
 */
export interface WorkbenchAgentHandle {
    readonly agent: WorkbenchAgent;
    dispose(): Promise<void>;
}
