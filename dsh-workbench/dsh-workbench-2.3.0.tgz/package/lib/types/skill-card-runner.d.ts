/**
 * Skill card runner: reads one session's skill catalog, runs a card's skill
 * through an independent child agent, and owns the retry, cancellation, and
 * timeout policy.
 *
 * The runner holds no durable state: a settled result goes to the store, and the
 * run table only carries what a polling client has to see until the next run. A
 * bare run skips the store entirely, because its whole result is whether it worked.
 * @module dsh-workbench/skill-card-runner
 */
import type { WorkbenchCardConfigView, WorkbenchCardModel, WorkbenchCardWorkspace, WorkbenchResultRecord, WorkbenchRunRequest, WorkbenchRunState, WorkbenchSandboxMode, WorkbenchSkillCardErrorCode, WorkbenchSkillCatalogEntry } from './skill-card-contract.ts';
import type { WorkbenchActivityEvent } from './skill-card-activity.ts';
import type { WorkbenchSkillCardHost, WorkbenchWorkingDirectory } from './skill-card-host.ts';
import type { WorkbenchDirectoryProbe } from './skill-card-directory.ts';
/** Outcome of reading one session's skill catalog. */
export type WorkbenchCatalogOutcome = {
    readonly status: 'ok';
    readonly entries: readonly WorkbenchSkillCatalogEntry[];
} | {
    readonly status: 'failed';
    readonly code: WorkbenchSkillCardErrorCode;
    readonly detail: string;
};
/** One refused start, shared by the two things a start resolves before it records a run. */
interface RejectedStart {
    readonly status: 'rejected';
    readonly code: WorkbenchSkillCardErrorCode;
    readonly detail: string;
}
/** Outcome of asking one card's run to start. */
export type WorkbenchRunStartOutcome = {
    readonly status: 'started';
    readonly state: WorkbenchRunState;
} | RejectedStart;
/** What one card is configured to run. */
export interface WorkbenchCardSelection {
    /** Selected skill; absent means the card is unconfigured. */
    readonly skill?: string;
    /** Template stored for the selected skill; absent means the card cannot run. */
    readonly template?: string;
    /**
     * Model the card runs on; absent means its runs inherit the session's model.
     *
     * Read from storage rather than from the request: the route a card runs on is part of
     * what the card is, so a client cannot start a run on a route the card does not name.
     */
    readonly model?: WorkbenchCardModel;
    /**
     * Directory the card runs in; absent means the card cannot run.
     *
     * Read from storage for the same reason the route is: where a card runs is part of what
     * the card is. There is no fallback to the session's directory — a run would then happen
     * somewhere the user never chose, and every result would be about a different folder.
     */
    readonly workspace?: WorkbenchCardWorkspace;
    /**
     * Sandbox mode the card's runs use; absent means the default mode applies.
     *
     * Read from storage for the same reason the route is: a permission is part of what the
     * card is, so a client cannot start a run under a mode the card does not name.
     */
    readonly permission?: WorkbenchSandboxMode;
}
/**
 * Project one stored card onto the selection a run reads.
 *
 * One function rather than an inline object built at composition, because every field a run
 * needs from the card record passes through here: a field the record holds and this
 * projection forgets is one missing line, not something a reader has to notice inside a
 * route assembly callback. Omitting `permission` here would leave every card on the default
 * mode while the page still showed the stored one.
 * @param card - the card as storage returns it, or undefined when none is stored.
 * @returns the selection; an absent field stays absent rather than becoming `undefined`.
 */
export declare function cardSelection(card: WorkbenchCardConfigView | undefined): WorkbenchCardSelection;
/** Everything the runner depends on. */ export interface WorkbenchSkillCardRunnerOptions {
    /** Host services, narrowed. */
    readonly host: WorkbenchSkillCardHost;
    /**
     * Optional working-directory service.
     *
     * Absent on channels whose pinned harness predates it; the runner then reads
     * the directory from the agent's session header, as that channel does.
     */
    readonly workingDirectory?: WorkbenchWorkingDirectory;
    /**
     * The one filesystem read a start performs.
     *
     * Required rather than defaulted: every run is gated on it, so a composition that
     * forgot to wire it cannot quietly behave as if there were no gate.
     */
    readonly statDirectory: WorkbenchDirectoryProbe;
    /** Configured child backend name. */
    readonly subagentProvider: string;
    /** Milliseconds one run may take before it is cancelled. */
    readonly runTimeoutMs: number;
    /** Runs allowed in flight across all cards. */
    readonly maxConcurrentRuns: number;
    /**
     * Read one card's stored configuration.
     *
     * The run request carries only what the client knows; whether a template
     * actually exists is the Host's own answer, and a template is the precondition
     * for running.
     */
    readonly selection: (cardId: string) => WorkbenchCardSelection;
    /**
     * Persist one card's settled result.
     * @param cardId - the card.
     * @param record - the complete result.
     * @returns resolution after durability.
     */
    readonly saveResult: (cardId: string, record: WorkbenchResultRecord) => Promise<void>;
    /** Host logger. */
    readonly warn: (message: string) => void;
    /** Clock seam; defaults to the wall clock. */
    readonly now?: () => number;
}
/**
 * Run one card's skill and own the outcome.
 *
 * A card may run several at once, bounded by the deployment's concurrency limit — each
 * run in a session of its own, which is what keeps two runs of one card from sharing a
 * conversation. A run that produces no usable structured value is retried exactly once;
 * a cancelled run never is.
 */
export declare class WorkbenchSkillCardRunner {
    private readonly options;
    /**
     * Every card's runs, in start order.
     *
     * A list rather than one record because one card may have several in flight: the last
     * entry is the newest, and each carries the id its settled record will use.
     */
    private readonly runs;
    private readonly inflight;
    private readonly now;
    private active;
    /**
     * The run ids handed out per card, in this process.
     *
     * A run's id is its start, so two runs of one card started within the same millisecond —
     * which is what a fixed clock in a spec produces — would be one id. The suffix keeps them
     * apart while the first keeps the readable form.
     */
    private readonly runStamps;
    /**
     * @param options - host services, budgets, and the two storage seams.
     */
    constructor(options: WorkbenchSkillCardRunnerOptions);
    /**
     * Highest session stamp published for each card, in this process.
     *
     * A session id cannot be published twice, and the id is the run's start — so two runs of
     * one card that start within the same millisecond, which is what a fixed clock in a spec
     * produces, would ask for the same id. Keeping the last stamp makes the second run's id
     * one greater than the first, so ids stay readable and unique without a random tag.
     */
    private readonly sessionStamps;
    /**
     * Read the skill catalog a card can choose from.
     *
     * The read always goes through an agent scope. A scope-less read returns the
     * global layer alone, and the shipped web composition disables the host's own
     * skill provider there, so it would answer with an empty list instead of the
     * installed skills.
     *
     * The named session's agent is preferred, because that is the agent the run will
     * use. With no session yet the catalog falls back to any live agent: a card is
     * configured before it is first run, and the installed skills are the same list
     * whichever live agent supplies the scope.
     * @param sessionId - the session to read through, when the card has one.
     * @returns the catalog, or why it could not be read.
     */
    catalog(sessionId: string | undefined): Promise<WorkbenchCatalogOutcome>;
    /**
     * Choose the agent whose scope supplies the catalog.
     * @param sessionId - the session to read through, when the card has one.
     * @returns that agent, another live one, or undefined when none is live.
     */
    private catalogAgent;
    /**
     * Start one card's run.
     *
     * Every precondition is answered before anything is started, so a rejected
     * start never leaves a child behind and never costs a model call.
     * @param request - card, what the run is asked to do, the session a refinement continues,
     * and the client's contract.
     * @returns the started run's state, or why it was refused.
     */
    start(request: WorkbenchRunRequest): Promise<WorkbenchRunStartOutcome>;
    /**
     * Whether one more start would exceed the deployment's limit.
     *
     * Asked twice per start: once before the run's session is resolved, so a refused start
     * publishes no session and restores none underneath a child still running in it, and once
     * immediately before the run is recorded, so the reservation itself stays synchronous.
     *
     * Only the deployment's limit is asked about: a card may have several runs in flight, and
     * refusing the second was what made a card a one-at-a-time thing. The limit counts every
     * run, so it bounds one card's concurrency as well as the whole workbench's.
     * @returns whether the limit is reached.
     */
    private congested;
    /**
     * Whether a run is already executing in one session.
     *
     * A refinement continues the conversation its document came from, and two agents on one
     * session would interleave two conversations into one log — so a refinement of a session
     * another run is inside is refused rather than merged. Plain runs are unaffected: each
     * gets a session of its own.
     * @param sessionId - the session the new run would execute in.
     * @returns the run already in that session, if there is one.
     */
    private sessionBusy;
    /**
     * Resolve the run seam this harness offers, bound to its service.
     *
     * Which seam exists is a property of the installed harness, so the runner adapts
     * rather than requires one: `startActivation` (0.2.1-alpha.2) is used as-is, and the
     * older channel's one-shot `start` (0.2.0-rc.2) is wrapped — its request carries the
     * same `prompt`, `parent`, `signal`, `outputSchema` and `agentOptions` (no `cwd`, no
     * `delivery`: the child inherits the parent's header at start and the result resolves
     * to the caller — all measured on a real host composition), and its handle carries
     * `id` where an activation carries `childId`. A harness offering neither returns
     * `undefined`, which the start path refuses with the seam detail.
     * @param subagents - the subagent service.
     * @returns the bound seam, or undefined when this harness offers no run seam.
     */
    private activationSeam;
    /**
     * Answer whether a card's route can actually be run here.
     *
     * Three separate reasons, and each refuses rather than falling back to the session's
     * model: a backend that cannot take a route, a provider this deployment does not route,
     * and a provider that no longer offers that model. The last two are told apart by the
     * registry itself — `listModels` rejects for a provider it does not have — and the
     * message names the route in every case, because "the model is gone" is only actionable
     * when it says which one.
     * @param providerName - configured subagent backend name.
     * @param canChooseModel - whether that backend advertises the `agentOptions` capability.
     * @param model - the route the card names.
     * @returns the refusal, or undefined when the route can be used.
     */
    private modelRefusal;
    /**
     * Record a child agent's failure against the run that started it.
     *
     * The subagent seam turns a faulted child into `stopReason: 'error'` and drops the
     * error itself, so this bus reading is the only account of what went wrong. An
     * agent this runner did not start is ignored.
     * @param agentId - the failing agent's identity, which is its session id.
     * @param error - the failure the agent reported.
     */
    observeAgentError(agentId: string, error: unknown): void;
    /**
     * Record one of a child agent's session events against the run that started it.
     *
     * The same bus, the same attribution rule, and the same "an agent this runner did not
     * start is ignored" contract as {@link observeAgentError}: the child's session id is the
     * identity both events carry. A `tool/call` becomes one call entry and an
     * `assistant/message` becomes its narration entries — the mapping lives in
     * `skill-card-activity.ts`, together with the redaction and the bounds.
     * @param sessionId - the session the event came from, which is the child's id.
     * @param event - the session event as the bus delivered it.
     */
    observeChildEvent(sessionId: string, event: WorkbenchActivityEvent): void;
    /**
     * Every run this runner keeps, across all cards.
     * @returns the runs, in no particular order.
     */
    private everyRun;
    /**
     * The runs this runner keeps for one card, oldest first.
     * @param cardId - the card.
     * @returns the runs; empty when none has been started.
     */
    private runsOf;
    /**
     * Read one card's newest run state.
     * @param cardId - the card.
     * @returns the state, or undefined when no run has been started for it.
     */
    state(cardId: string): WorkbenchRunState | undefined;
    /**
     * Read every run state one card still keeps, newest first.
     *
     * A card may run several at once, so a client needs the list: the newest state alone
     * would hide a second run in flight. Newest first is the order the history reads in, and
     * the order the list settles into once the runs are stored.
     * @param cardId - the card.
     * @returns the states; empty when no run has been started.
     */
    states(cardId: string): WorkbenchRunState[];
    /**
     * Cancel one of a card's in-flight runs, or all of them.
     *
     * Naming a run stops that one: a card with two runs in flight has two stopping stories,
     * and a reader who wants one of them stopped should not have to stop the other. Naming
     * none stops whatever is in flight for the card, which is the control the card's own
     * header offers.
     * @param cardId - the card.
     * @param runId - the run to stop; absent stops every run in flight for the card.
     * @returns whether any running run was signalled.
     */
    cancel(cardId: string, runId?: string): boolean;
    /**
     * Cancel every in-flight run and wait for them to settle.
     * @returns resolution once no run is still executing.
     */
    dispose(): Promise<void>;
    /**
     * Mint one run's identity within its card.
     *
     * The start time is the id, so a record's identity reads as the moment the run began and
     * the live row can be matched to the stored record it becomes. Two runs of one card that
     * start in the same millisecond — a fixed clock, or a fast double click — take a counter
     * suffix, so the second keeps a distinct id instead of overwriting the first's row.
     * @param cardId - the card the run belongs to.
     * @param startedAt - the run's start in milliseconds since the epoch.
     * @returns the id.
     */
    private nextRunId;
    /**
     * File one run into its card's table, keeping the table bounded.
     *
     * A run is kept while it is in flight and after it settles, because the row a reader is
     * watching is the run itself — a cancelled run in particular stores nothing, so this
     * table is the only place its row exists. The bound drops the oldest settled runs once
     * the table is full; a run in flight is never dropped.
     * @param run - the run just started.
     */
    private retain;
    /**
     * Publish the session one card run executes in, with the card's permission mode applied.
     *
     * A card's run gets a session of its own rather than joining the conversation the user is
     * having: the run is the card's work, and every card sharing one session would mix every
     * card's traffic into one conversation. The session is rooted at the card's directory, and
     * a child inherits its parent's session header — which is where the sandbox derives its
     * writable root from — so this agent is the whole mechanism that fences the run; no `cwd`
     * is passed and the seam stays untouched. See docs/workbench-workspace-fence-plan.md.
     *
     * The mode is applied once, here, at creation. A child inherits its parent's explicit
     * override, so recording it on this agent is what makes the card's permission govern the
     * run started from it.
     * @param cardId - the card whose run is starting.
     * @param cwd - the card's workspace directory, which roots the session.
     * @param startedAt - the run's start, used to name the session.
     * @returns the resolved session, or why it could not be published.
     * @throws {WorkbenchSandboxModeError} when the mode cannot be applied; the agent is
     * released first, so a refused start leaves nothing running under no mode.
     */
    private openRunSession;
    /**
     * Re-attach the session a refinement continues.
     *
     * The session was archived when its own run settled, and the harness refuses a model step
     * to an archived session or to a subagent descendant of one — so the run restores it,
     * runs there, and archives it again when it settles. A live agent is used as it is; one
     * that is gone is resumed from persistence, because `create` refuses an id that already
     * exists durably and a fresh session would be a different conversation.
     *
     * A session that is not archived is left that way: it is on screen because someone is in
     * it, and hiding a conversation the user has open is not this run's decision.
     * @param sessionId - the session recorded on the result being refined.
     * @param route - the route to install on a resumed agent that was persisted without
     * one; see {@link publishRunSession} for the warrant.
     * @returns the resolved session, or why it could not be restored.
     */
    private attachRunSession;
    /**
     * Wrap one agent as the run's session, owning the archive and the release together.
     *
     * One wrapper for both cases because the promise is the same either way: whatever the run
     * did, its session ends where it started — archived for a session this feature published,
     * archived again for one it restored — and the agent is released. Settling never throws,
     * because a captured result must not become a failure because teardown did; each step
     * warns instead.
     * @param agent - the run's live agent.
     * @param handle - the disposer that releases it, when this run is the one that acquired
     * it. Absent for an agent that was already live, which this run does not own.
     * @param archive - whether this session is archived when the run settles.
     * @returns the run's session.
     */
    private ownedSession;
    /**
     * Publish one fresh session for a run.
     *
     * The id is the card and the run's start, which is readable in a session list and needs
     * no random tag: a card runs once at a time, so the start is unique. A session id cannot
     * be published twice, though — a durable store still holds the session an earlier app run
     * created under the same millisecond — so a refused publication is retried once under the
     * next stamp instead of failing a run the user started.
     * @param cardId - the card whose run is starting.
     * @param cwd - the card's workspace directory, which roots the session.
     * @param startedAt - the run's start, used to name the session.
     * @param route - the provider/model the session runs on, when one is named. A run
     * session is created blank and assembles the deployment persona from its own options,
     * whose `{{model}}` placeholder would have no value otherwise; the card's route or
     * the naming session's route is what gives both the session and the subagent it
     * parents a model to assemble against.
     * @returns the created agent and its handle.
     */
    private publishRunSession;
    /**
     * Name one run's session.
     *
     * The stamp never goes backwards for a card, so two runs that start within the same
     * millisecond — which a fixed clock in a spec produces — cannot ask for the same id.
     * @param cardId - the card whose run is starting.
     * @param startedAt - the run's start in milliseconds since the epoch.
     * @returns the session id.
     */
    private nextSessionId;
    /**
     * Release one agent, warning instead of throwing.
     * @param handle - the agent to release.
     * @returns resolution once the release was attempted.
     */
    private releaseAgent;
    /**
     * Run one card's skill to a terminal state.
     * @param run - the run record to settle.
     * @param input - the run's agent, the agent whose scope resolves the skill definition,
     * the skill name, and the output contract.
     * @param activate - the run seam, already known to exist and bound to its service.
     * @returns resolution after the run reaches a terminal phase.
     */
    private execute;
    /**
     * Run the child once.
     * @param run - the run record owning cancellation.
     * @param input - the agent, skill, and either the card's template and contract or nothing.
     * @param cwd - the agent's working directory.
     * @param skill - the loaded skill.
     * @param activate - the run seam, known to exist.
     * @returns the attempt's outcome.
     */
    private attempt;
    /**
     * Settle one run from its last attempt.
     *
     * Both a captured and an unusable result are kept: the card renders the value
     * when there is one, and the text output is what "view raw output" shows when
     * there is not. A bare run settles the same way but stores nothing.
     * @param run - the run record to settle.
     * @param outcome - the last attempt's outcome.
     * @returns resolution after the result is durable, or immediately for a bare run.
     */
    private finish;
    /**
     * Resolve the agent's effective working directory.
     *
     * The service is preferred when the deployment has it; otherwise the session
     * header carries the same value, which is how the older channel resolves it.
     * @param agent - the agent.
     * @param signal - cancellation.
     * @returns the directory, or undefined when neither source supplies one.
     */
    private cwdFor;
    /**
     * Project one run record onto the wire state.
     * @param run - the run record.
     * @returns the wire state.
     */
    private stateOf;
}
export {};
